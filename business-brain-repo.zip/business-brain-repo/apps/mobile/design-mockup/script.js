const toggleBtn = document.getElementById('toggleBtn');
const insights = document.getElementById('insights');
const recordSaleBtn = document.getElementById('recordSaleBtn');

let expanded = false;

toggleBtn.addEventListener('click', () => {
  expanded = !expanded;
  toggleBtn.textContent = expanded ? 'Show less' : 'View full briefing';

  if (expanded) {
    const extra = document.createElement('div');
    extra.className = 'insight positive';
    extra.style.animationDelay = '0s';
    extra.innerHTML = `
      <span class="dot"></span>
      <p>You have <strong>2 customers</strong> who usually buy weekly but haven't returned in 10 days — worth a quick check-in.</p>
    `;
    extra.id = 'extraInsight';
    insights.appendChild(extra);
  } else {
    const extra = document.getElementById('extraInsight');
    if (extra) extra.remove();
  }
});

recordSaleBtn.addEventListener('click', () => {
  recordSaleBtn.textContent = 'Sale recorded ✓';
  recordSaleBtn.style.opacity = '0.8';
  setTimeout(() => {
    recordSaleBtn.innerHTML = '<span class="icon">＋</span> Record Sale';
    recordSaleBtn.style.opacity = '1';
  }, 1200);
});
