# BUSINESS BRAIN — CORE DATA MODEL (v1)

## Design principle before the entities

Every archetype module (Pharmacy, Hospitality, Salon, etc.) needs to extend the Core without forking it. The pattern that makes this possible: **every core entity carries a small set of universal fields, plus one flexible `attributes` field that holds archetype-specific data.** This means the Pharmacy module can add "batch_number" and "expiry_date" to a Product without the Core schema ever needing to change, and a Hotel module can add "room_number" and "bed_type" to the same underlying entity. One schema, many shapes — this is what makes "universal core + ten modules" technically real, not just a nice diagram.

---

## Core Entities

### Business
The account itself. One record per business using Business Brain.
- id, name, archetype_type (which of the 10 modules is active, can be more than one), owner_user_id, phone, address, created_at
- settings (currency, language, timezone)
- compliance_profile (which licenses/registrations apply — feeds the Compliance Guardian)

### User (staff/owner)
- id, business_id, name, phone, role (owner/manager/staff), permission_level
- Feeds the Staff Accountability Layer — every action below is tied to a user_id for audit purposes

### Customer
- id, business_id, name, phone, notes
- last_interaction_date (powers "hasn't returned in X days" alerts across every archetype)
- attributes (archetype-specific: patient history for Clinical, guest preferences for Hospitality, etc.)

### Supplier
- id, business_id, name, phone, reliability_score (starts neutral, adjusted by Guardian based on delivery consistency, verification failures for Pharmacy, etc.)

### Item
The generic unit of what's sold or provided — a product, a room-night, an appointment slot, a service, a project.
- id, business_id, name, category, unit_price, cost_price
- tracks_inventory (boolean — false for services/appointments/projects)
- attributes (archetype-specific: size/color for Retail, batch/expiry for Pharmacy, recipe/ingredients for Restaurant, room_type for Hotel)

### Transaction
The universal record of money changing hands or being owed — a sale, a booking payment, a claim, an invoice.
- id, business_id, customer_id, user_id (who recorded it), type (sale/booking/invoice/claim), status (paid/partial/owed/overdue)
- total_amount, amount_paid, amount_owed, due_date
- created_at, channel (in-house/WhatsApp/delivery-aggregator/OTA — supports the multi-channel unification idea from Archetype 3/4)

### TransactionLineItem
- id, transaction_id, item_id, quantity, unit_price, subtotal

### Payment
- id, transaction_id, amount, method (cash/POS/transfer/Paystack/Flutterwave), paid_at

### LedgerEntry (the generalized "debt" record)
This is the entity that generalizes across Customer Debt (Archetype 1), HMO Claims (Archetype 6), and School Fees (Archetype 10) — same underlying shape, different attributes.
- id, business_id, customer_id (or third-party payer like an HMO), linked_transaction_id
- amount_owed, amount_paid, age_days (calculated), status (current/overdue/escalated/resolved)
- attributes (archetype-specific: HMO authorization code + rejection_reason for Clinical; installment_plan + sibling_discount for Education)
- escalation_stage (drives the auto-escalating reminder tone from Archetype 1's research)

### Expense
- id, business_id, category, amount, date, linked_to (optional — e.g. tied to a specific batch/production run for cost-per-unit tracking)

### InventoryMovement
- id, business_id, item_id, type (sale/restock/waste/adjustment/transfer), quantity, reason, user_id, timestamp
- Powers shrinkage detection, waste-cost narration, and reorder point recalculation

### Appointment/Booking
For archetypes with scheduling (Hospitality, Appointment Services, Clinical, Logistics pickups)
- id, business_id, customer_id, item_id (room/service/slot), start_time, end_time, status (booked/confirmed/no-show/completed/cancelled)
- deposit_amount, reminder_sent_at

### ComplianceItem
Generalizes the Compliance Guardian pattern found in Pharmacy, Manufacturing, Clinical, and Logistics.
- id, business_id, license_type (PCN/NAFDAC/NIPOST/PCN-controlled-substances/etc.), issue_date, expiry_date, status
- Guardian watches this table and prompts ahead of expiry, regardless of archetype

### GuardianEvent (the alert log)
Every Guardian narration gets logged here — this is what makes the Daily Briefing possible (it's just a summarized query of yesterday's GuardianEvents).
- id, business_id, type (low_stock/overdue_debt/compliance_expiry/anomaly/pattern_insight/etc.), message, severity, created_at, resolved (boolean)
- linked_entity (points back to the Item/LedgerEntry/ComplianceItem that triggered it)

---

## Why this shape works across all 10 archetypes

| Archetype need | Core entity it reuses |
|---|---|
| Retail reorder points | Item + InventoryMovement |
| Pharmacy expiry/batch | Item.attributes |
| Restaurant recipe deduction | Item (recipe) → InventoryMovement on sale |
| Hotel room availability | Item (room) + Appointment |
| Salon booking + no-show | Appointment |
| Clinical patient record | Customer.attributes + NDPR consent flag |
| HMO claims aging | LedgerEntry.attributes |
| Farm feed conversion | Expense (feed) + Item (birds) + InventoryMovement |
| Manufacturing cost-per-unit | Expense linked to production batch |
| School fee installments | LedgerEntry.attributes |
| Logistics delivery + proof | Appointment (delivery) + attributes (photo_url) |

Every "signature intelligence feature" from the blueprint reads from these same tables — Cross-Business Intelligence aggregates GuardianEvents and Transactions across businesses; the Business Health Score is computed from LedgerEntry + Transaction + Expense; Cash-Flow Forecasting projects from Transaction due_dates and historical patterns. Nothing needs a separate data store.

---

## What's deliberately NOT in this version

- No archetype-specific tables (e.g. no "Prescription" table) — that logic lives entirely in `attributes` fields and archetype-specific business logic layered on top, keeping the Core genuinely archetype-agnostic as the blueprint requires
- No multi-currency/multi-country handling yet — single-currency assumption for v1, revisit only when expansion beyond Nigeria becomes real
- No offline sync conflict-resolution logic specified yet — this needs its own design pass once the tech stack (step 2) is chosen, since the approach differs by database choice
